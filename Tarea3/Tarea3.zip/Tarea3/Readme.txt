Tarea 3 Ejercicio 1

Para compilar el programa, abra una ventana de comandos y escriba:

gcc  Tarea3_1.cpp -o Tarea3_1.exe

Para ejecutar el programa, abra una ventana de comandos y escriba:

./Tarea3_1.exe archivo1.txt
o,
./Tarea3_1.exe archivo2.txt

Tarea 3 Ejercicio 2

Para compilar el programa, abra una ventana de comandos y escriba:

gcc  Tarea3_2.cpp -o Tarea3_2.exe

Para ejecutar el programa, abra una ventana de comandos y escriba:

./Tarea3_2.exe <base> <exponente>

Ejemplo:

./Tarea3_2.exe 2 5